<?php

namespace MyEntities;
use \PostTypeBuilder\Entity;

class Book extends Entity{
    /** @Property */
    public $number_of_pages;
	
    /** @Property(type="Author") */
    public $author;
	
    /** @Property(type="Chapter") */
    public $chapters = array();
}
