<?php

namespace MyEntities;
use \PostTypeBuilder\Entity;

class Author extends Entity{
    /** @Property */
    public $year_of_birth;
	
    /** @Property */
    public $year_of_demise;
}
