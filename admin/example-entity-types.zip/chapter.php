<?php

namespace MyEntities;
use \PostTypeBuilder\Entity;

class Chapter extends Entity{
    /** @Property */
    public $number_of_pages;
	
    /** @Property(type="LongText") */
    public $contents;
}
